// Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";
import Firebase  from "firebase/compat/app";
import "firebase/compat/database";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAsshxbF-FiVkrfSCASmDTG17V2_nunkZk",
  authDomain: "rajanvanikar07.firebaseapp.com",
  databaseURL: "https://rajanvanikar07-default-rtdb.firebaseio.com",
  projectId: "rajanvanikar07",
  storageBucket: "rajanvanikar07.appspot.com",
  messagingSenderId: "799082697482",
  appId: "1:799082697482:web:3836f202f633abdd7da0f3",
  measurementId: "G-FEJ2T11EQC"
};

// Initialize Firebase
Firebase.initializeApp(firebaseConfig);
// const analytics = getAnalytics(app);
export default Firebase;